"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  ChevronLeft,
  ChevronRight,
  Users,
  Scale,
  FileText,
  Gavel,
  Clock,
  CheckCircle,
  Save,
  Download,
  Eye,
} from "lucide-react"

interface WizardData {
  // Step 1: Parties & Contact
  senderName: string
  senderAddress: string
  senderEmail: string
  senderPhone: string
  recipientName: string
  recipientAddress: string
  recipientEmail: string
  recipientPhone: string

  // Step 2: Matter Category & Jurisdiction
  noticeType: string
  jurisdiction: string
  category: string

  // Step 3: Facts & Timeline
  factsSummary: string
  timeline: string
  incidentDate: string

  // Step 4: Legal Grounds
  legalGrounds: string[]
  statutes: string
  contractClauses: string

  // Step 5: Demands & Deadlines
  demands: string
  paymentAmount: string
  responseDeadline: string
  complianceDeadline: string

  // Step 6: Review & Signature
  signatoryName: string
  signatoryTitle: string
  signaturePlace: string
  signatureDate: string
}

const initialData: WizardData = {
  senderName: "",
  senderAddress: "",
  senderEmail: "",
  senderPhone: "",
  recipientName: "",
  recipientAddress: "",
  recipientEmail: "",
  recipientPhone: "",
  noticeType: "",
  jurisdiction: "",
  category: "",
  factsSummary: "",
  timeline: "",
  incidentDate: "",
  legalGrounds: [],
  statutes: "",
  contractClauses: "",
  demands: "",
  paymentAmount: "",
  responseDeadline: "",
  complianceDeadline: "",
  signatoryName: "",
  signatoryTitle: "",
  signaturePlace: "",
  signatureDate: new Date().toISOString().split("T")[0],
}

const steps = [
  { id: 1, title: "Parties & Contact", icon: Users, description: "Sender and recipient information" },
  { id: 2, title: "Category & Jurisdiction", icon: Scale, description: "Notice type and legal jurisdiction" },
  { id: 3, title: "Facts & Timeline", icon: FileText, description: "Incident details and chronology" },
  { id: 4, title: "Legal Grounds", icon: Gavel, description: "Applicable laws and regulations" },
  { id: 5, title: "Demands & Deadlines", icon: Clock, description: "Required actions and timeframes" },
  { id: 6, title: "Review & Signature", icon: CheckCircle, description: "Final review and execution" },
]

const noticeTypes = [
  { value: "cease-desist", label: "Cease & Desist" },
  { value: "demand-payment", label: "Payment Demand" },
  { value: "breach-contract", label: "Breach of Contract" },
  { value: "eviction", label: "Eviction Notice" },
  { value: "termination", label: "Termination Notice" },
  { value: "compliance", label: "Compliance Notice" },
  { value: "copyright", label: "Copyright Infringement" },
  { value: "trademark", label: "Trademark Violation" },
  { value: "debt-collection", label: "Debt Collection" },
  { value: "property-dispute", label: "Property Dispute" },
]

const legalGroundsOptions = [
  "Breach of Contract",
  "Copyright Infringement",
  "Trademark Violation",
  "Defamation",
  "Harassment",
  "Property Damage",
  "Unpaid Debt",
  "Lease Violation",
  "Employment Issues",
  "Consumer Protection",
  "Privacy Violation",
  "Unfair Competition",
]

export function LegalNoticeWizard() {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState<WizardData>(initialData)
  const [generatedNotice, setGeneratedNotice] = useState("")
  const [isSaved, setIsSaved] = useState(false)

  // Auto-save functionality
  useEffect(() => {
    const timer = setTimeout(() => {
      localStorage.setItem("legal-notice-draft", JSON.stringify(formData))
      setIsSaved(true)
      setTimeout(() => setIsSaved(false), 2000)
    }, 1000)

    return () => clearTimeout(timer)
  }, [formData])

  // Load saved draft on mount
  useEffect(() => {
    const saved = localStorage.getItem("legal-notice-draft")
    if (saved) {
      setFormData(JSON.parse(saved))
    }
  }, [])

  const updateFormData = (field: keyof WizardData, value: string | string[]) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const toggleLegalGround = (ground: string) => {
    const current = formData.legalGrounds
    const updated = current.includes(ground) ? current.filter((g) => g !== ground) : [...current, ground]
    updateFormData("legalGrounds", updated)
  }

  const generatePreview = () => {
    const currentDate = new Date().toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    const notice = `
LEGAL NOTICE

Date: ${currentDate}

TO: ${formData.recipientName}
${formData.recipientAddress}
${formData.recipientEmail ? `Email: ${formData.recipientEmail}` : ""}
${formData.recipientPhone ? `Phone: ${formData.recipientPhone}` : ""}

FROM: ${formData.senderName}
${formData.senderAddress}
${formData.senderEmail ? `Email: ${formData.senderEmail}` : ""}
${formData.senderPhone ? `Phone: ${formData.senderPhone}` : ""}

RE: ${noticeTypes.find((t) => t.value === formData.noticeType)?.label || formData.noticeType}
JURISDICTION: ${formData.jurisdiction}

Dear ${formData.recipientName},

You are hereby notified of the following matter:

FACTS AND CIRCUMSTANCES:
${formData.factsSummary}

${formData.incidentDate ? `INCIDENT DATE: ${formData.incidentDate}` : ""}

${formData.timeline ? `TIMELINE:\n${formData.timeline}` : ""}

LEGAL GROUNDS:
${formData.legalGrounds.length > 0 ? formData.legalGrounds.join(", ") : "Not specified"}

${formData.statutes ? `APPLICABLE STATUTES:\n${formData.statutes}` : ""}

${formData.contractClauses ? `CONTRACT PROVISIONS:\n${formData.contractClauses}` : ""}

DEMANDS:
${formData.demands}

${formData.paymentAmount ? `PAYMENT AMOUNT: ${formData.paymentAmount}` : ""}

DEADLINE FOR RESPONSE: ${formData.responseDeadline}
${formData.complianceDeadline ? `COMPLIANCE DEADLINE: ${formData.complianceDeadline}` : ""}

Failure to respond or comply within the specified timeframe may result in further legal action without additional notice.

Please govern yourself accordingly.

Dated: ${formData.signatureDate}
Place: ${formData.signaturePlace}

${formData.signatoryName}
${formData.signatoryTitle}

---
DISCLAIMER: This document was generated using an automated legal notice generator. This tool generates document drafts and does not constitute legal advice. Please consult with a qualified attorney before using this notice.
    `.trim()

    setGeneratedNotice(notice)
  }

  const downloadNotice = () => {
    const blob = new Blob([generatedNotice], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `legal-notice-${formData.recipientName.replace(/\s+/g, "-").toLowerCase()}-${new Date().toISOString().split("T")[0]}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const openPreviewPage = () => {
    // Store the generated notice in localStorage for the preview page
    localStorage.setItem(
      "preview-document",
      JSON.stringify({
        title: noticeTypes.find((t) => t.value === formData.noticeType)?.label || "Legal Notice",
        content: generatedNotice,
        isDraft: true,
        metadata: {
          created: new Date().toLocaleDateString(),
          sender: formData.senderName,
          recipient: formData.recipientName,
          type: noticeTypes.find((t) => t.value === formData.noticeType)?.label || "Legal Notice",
        },
      }),
    )

    // Navigate to preview page
    window.open("/preview", "_blank")
  }

  const nextStep = () => {
    if (currentStep < 6) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const progress = (currentStep / 6) * 100

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Users className="h-5 w-5" />
                    Sender Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="senderName">Full Name / Organization *</Label>
                    <Input
                      id="senderName"
                      value={formData.senderName}
                      onChange={(e) => updateFormData("senderName", e.target.value)}
                      placeholder="Your full legal name or organization"
                    />
                  </div>
                  <div>
                    <Label htmlFor="senderAddress">Complete Address *</Label>
                    <Textarea
                      id="senderAddress"
                      value={formData.senderAddress}
                      onChange={(e) => updateFormData("senderAddress", e.target.value)}
                      placeholder="Street address, city, state, ZIP code"
                      rows={3}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="senderEmail">Email Address</Label>
                      <Input
                        id="senderEmail"
                        type="email"
                        value={formData.senderEmail}
                        onChange={(e) => updateFormData("senderEmail", e.target.value)}
                        placeholder="your@email.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="senderPhone">Phone Number</Label>
                      <Input
                        id="senderPhone"
                        value={formData.senderPhone}
                        onChange={(e) => updateFormData("senderPhone", e.target.value)}
                        placeholder="(555) 123-4567"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Users className="h-5 w-5" />
                    Recipient Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="recipientName">Full Name / Organization *</Label>
                    <Input
                      id="recipientName"
                      value={formData.recipientName}
                      onChange={(e) => updateFormData("recipientName", e.target.value)}
                      placeholder="Recipient's full legal name or organization"
                    />
                  </div>
                  <div>
                    <Label htmlFor="recipientAddress">Complete Address *</Label>
                    <Textarea
                      id="recipientAddress"
                      value={formData.recipientAddress}
                      onChange={(e) => updateFormData("recipientAddress", e.target.value)}
                      placeholder="Street address, city, state, ZIP code"
                      rows={3}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="recipientEmail">Email Address</Label>
                      <Input
                        id="recipientEmail"
                        type="email"
                        value={formData.recipientEmail}
                        onChange={(e) => updateFormData("recipientEmail", e.target.value)}
                        placeholder="recipient@email.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="recipientPhone">Phone Number</Label>
                      <Input
                        id="recipientPhone"
                        value={formData.recipientPhone}
                        onChange={(e) => updateFormData("recipientPhone", e.target.value)}
                        placeholder="(555) 123-4567"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Scale className="h-5 w-5" />
                  Matter Category & Jurisdiction
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="noticeType">Notice Type *</Label>
                    <Select value={formData.noticeType} onValueChange={(value) => updateFormData("noticeType", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select notice type" />
                      </SelectTrigger>
                      <SelectContent>
                        {noticeTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="jurisdiction">Jurisdiction *</Label>
                    <Input
                      id="jurisdiction"
                      value={formData.jurisdiction}
                      onChange={(e) => updateFormData("jurisdiction", e.target.value)}
                      placeholder="e.g., State of California, Federal"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="category">Matter Category</Label>
                  <Select value={formData.category} onValueChange={(value) => updateFormData("category", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="contract">Contract Dispute</SelectItem>
                      <SelectItem value="property">Property Matter</SelectItem>
                      <SelectItem value="intellectual">Intellectual Property</SelectItem>
                      <SelectItem value="employment">Employment Issue</SelectItem>
                      <SelectItem value="consumer">Consumer Protection</SelectItem>
                      <SelectItem value="debt">Debt Collection</SelectItem>
                      <SelectItem value="personal">Personal Injury</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 3:
        return (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <FileText className="h-5 w-5" />
                  Facts & Timeline
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="factsSummary">Summary of Facts *</Label>
                  <Textarea
                    id="factsSummary"
                    value={formData.factsSummary}
                    onChange={(e) => updateFormData("factsSummary", e.target.value)}
                    placeholder="Provide a clear, factual description of the issue or dispute..."
                    rows={6}
                    className="resize-none"
                  />
                  <p className="text-sm text-slate-600 mt-1">
                    Be specific and factual. Avoid emotional language or opinions.
                  </p>
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="incidentDate">Incident Date</Label>
                    <Input
                      id="incidentDate"
                      type="date"
                      value={formData.incidentDate}
                      onChange={(e) => updateFormData("incidentDate", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="timeline">Timeline of Events</Label>
                    <Textarea
                      id="timeline"
                      value={formData.timeline}
                      onChange={(e) => updateFormData("timeline", e.target.value)}
                      placeholder="Chronological sequence of relevant events..."
                      rows={4}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 4:
        return (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Gavel className="h-5 w-5" />
                  Legal Grounds
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label>Legal Grounds (Select all that apply)</Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
                    {legalGroundsOptions.map((ground) => (
                      <Badge
                        key={ground}
                        variant={formData.legalGrounds.includes(ground) ? "default" : "outline"}
                        className="cursor-pointer justify-center py-2 px-3"
                        onClick={() => toggleLegalGround(ground)}
                      >
                        {ground}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <Label htmlFor="statutes">Applicable Statutes or Regulations</Label>
                  <Textarea
                    id="statutes"
                    value={formData.statutes}
                    onChange={(e) => updateFormData("statutes", e.target.value)}
                    placeholder="Cite specific laws, statutes, or regulations..."
                    rows={4}
                  />
                </div>
                <div>
                  <Label htmlFor="contractClauses">Contract Clauses (if applicable)</Label>
                  <Textarea
                    id="contractClauses"
                    value={formData.contractClauses}
                    onChange={(e) => updateFormData("contractClauses", e.target.value)}
                    placeholder="Reference specific contract provisions or clauses..."
                    rows={4}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 5:
        return (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Clock className="h-5 w-5" />
                  Demands & Deadlines
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="demands">Specific Demands *</Label>
                  <Textarea
                    id="demands"
                    value={formData.demands}
                    onChange={(e) => updateFormData("demands", e.target.value)}
                    placeholder="Clearly state what you want the recipient to do or stop doing..."
                    rows={5}
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="paymentAmount">Payment Amount (if applicable)</Label>
                    <Input
                      id="paymentAmount"
                      value={formData.paymentAmount}
                      onChange={(e) => updateFormData("paymentAmount", e.target.value)}
                      placeholder="$0.00"
                    />
                  </div>
                  <div>
                    <Label htmlFor="responseDeadline">Response Deadline *</Label>
                    <Input
                      id="responseDeadline"
                      value={formData.responseDeadline}
                      onChange={(e) => updateFormData("responseDeadline", e.target.value)}
                      placeholder="e.g., 30 days from receipt"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="complianceDeadline">Compliance Deadline</Label>
                  <Input
                    id="complianceDeadline"
                    value={formData.complianceDeadline}
                    onChange={(e) => updateFormData("complianceDeadline", e.target.value)}
                    placeholder="e.g., 15 days from response"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 6:
        return (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <CheckCircle className="h-5 w-5" />
                  Review & Signature
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="signatoryName">Signatory Name *</Label>
                    <Input
                      id="signatoryName"
                      value={formData.signatoryName}
                      onChange={(e) => updateFormData("signatoryName", e.target.value)}
                      placeholder="Name of person signing"
                    />
                  </div>
                  <div>
                    <Label htmlFor="signatoryTitle">Title/Position</Label>
                    <Input
                      id="signatoryTitle"
                      value={formData.signatoryTitle}
                      onChange={(e) => updateFormData("signatoryTitle", e.target.value)}
                      placeholder="e.g., Attorney, CEO, Owner"
                    />
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="signaturePlace">Place of Signature *</Label>
                    <Input
                      id="signaturePlace"
                      value={formData.signaturePlace}
                      onChange={(e) => updateFormData("signaturePlace", e.target.value)}
                      placeholder="City, State"
                    />
                  </div>
                  <div>
                    <Label htmlFor="signatureDate">Date *</Label>
                    <Input
                      id="signatureDate"
                      type="date"
                      value={formData.signatureDate}
                      onChange={(e) => updateFormData("signatureDate", e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex gap-4">
                  <Button onClick={generatePreview} className="flex-1">
                    <Eye className="h-4 w-4 mr-2" />
                    Generate Preview
                  </Button>
                  {generatedNotice && (
                    <>
                      <Button onClick={openPreviewPage} variant="outline">
                        <FileText className="h-4 w-4 mr-2" />
                        Full Preview
                      </Button>
                      <Button onClick={downloadNotice} variant="outline">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      {/* Main Wizard */}
      <div className="lg:col-span-2 space-y-6">
        {/* Progress Header */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-slate-900">
                Step {currentStep} of 6: {steps[currentStep - 1].title}
              </h2>
              <div className="flex items-center gap-2">
                {isSaved && (
                  <Badge variant="outline" className="text-green-600 border-green-200">
                    <Save className="h-3 w-3 mr-1" />
                    Saved
                  </Badge>
                )}
                <span className="text-sm text-slate-600">{Math.round(progress)}% Complete</span>
              </div>
            </div>
            <Progress value={progress} className="mb-4" />
            <p className="text-slate-600">{steps[currentStep - 1].description}</p>
          </CardContent>
        </Card>

        {/* Step Content */}
        {renderStep()}

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 1}
            className="flex items-center gap-2 bg-transparent"
          >
            <ChevronLeft className="h-4 w-4" />
            Previous
          </Button>
          <Button onClick={nextStep} disabled={currentStep === 6} className="flex items-center gap-2">
            Next
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Sidebar - Steps & Preview */}
      <div className="space-y-6">
        {/* Steps Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Progress</CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            <div className="space-y-3">
              {steps.map((step) => {
                const Icon = step.icon
                const isCompleted = step.id < currentStep
                const isCurrent = step.id === currentStep

                return (
                  <div
                    key={step.id}
                    className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-colors ${
                      isCurrent
                        ? "bg-blue-50 border border-blue-200"
                        : isCompleted
                          ? "bg-green-50"
                          : "hover:bg-slate-50"
                    }`}
                    onClick={() => setCurrentStep(step.id)}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        isCurrent ? "bg-blue-600 text-white" : isCompleted ? "bg-green-600 text-white" : "bg-slate-200"
                      }`}
                    >
                      {isCompleted ? <CheckCircle className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p
                        className={`font-medium text-sm ${
                          isCurrent ? "text-blue-900" : isCompleted ? "text-green-900" : "text-slate-700"
                        }`}
                      >
                        {step.title}
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Live Preview */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Live Preview</CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {generatedNotice ? (
              <div className="bg-slate-50 p-4 rounded-lg border text-xs font-mono leading-relaxed max-h-96 overflow-y-auto">
                <pre className="whitespace-pre-wrap">{generatedNotice}</pre>
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500">
                <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Complete the wizard to see your notice preview</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
