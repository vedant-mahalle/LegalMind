import { Linkedin, Twitter } from "lucide-react"

export function TeamSection() {
  const team = [
    {
      name: "Sarah Johnson",
      role: "CEO & Legal Expert",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Former corporate lawyer with 15+ years of experience in legal document creation and compliance.",
      social: {
        linkedin: "#",
        twitter: "#",
      },
    },
    {
      name: "Michael Chen",
      role: "CTO & AI Engineer",
      image: "/placeholder.svg?height=300&width=300",
      bio: "AI specialist with expertise in natural language processing and legal technology solutions.",
      social: {
        linkedin: "#",
        twitter: "#",
      },
    },
    {
      name: "Emily Rodriguez",
      role: "Head of Legal Research",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Legal researcher ensuring all generated documents meet current legal standards and requirements.",
      social: {
        linkedin: "#",
        twitter: "#",
      },
    },
  ]

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-card/30">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="font-montserrat font-black text-3xl sm:text-4xl text-foreground mb-4">Meet Our Team</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Legal experts and technology innovators working together to revolutionize legal document creation
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {team.map((member, index) => (
            <div
              key={index}
              className="bg-card border border-border rounded-lg p-6 text-center group hover:border-accent/50 transition-colors duration-200"
            >
              <div className="mb-6">
                <img
                  src={member.image || "/placeholder.svg"}
                  alt={member.name}
                  className="w-32 h-32 rounded-full mx-auto object-cover border-4 border-accent/20 group-hover:border-accent/40 transition-colors duration-200"
                />
              </div>
              <h3 className="font-montserrat font-bold text-xl text-card-foreground mb-2">{member.name}</h3>
              <p className="text-accent font-semibold mb-4">{member.role}</p>
              <p className="text-muted-foreground leading-relaxed mb-6">{member.bio}</p>
              <div className="flex justify-center space-x-4">
                <a
                  href={member.social.linkedin}
                  className="text-muted-foreground hover:text-accent transition-colors duration-200"
                >
                  <Linkedin className="h-5 w-5" />
                </a>
                <a
                  href={member.social.twitter}
                  className="text-muted-foreground hover:text-accent transition-colors duration-200"
                >
                  <Twitter className="h-5 w-5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
