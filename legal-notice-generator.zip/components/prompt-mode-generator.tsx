"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { MessageSquare, Sparkles, FileText, AlertCircle, CheckCircle, Download } from "lucide-react"

interface PromptData {
  prompt: string
  senderName: string
  recipientName: string
  jurisdiction: string
  deadline: string
  urgency: string
}

const urgencyLevels = [
  { value: "low", label: "Standard (30+ days)", color: "bg-green-100 text-green-800" },
  { value: "medium", label: "Urgent (7-30 days)", color: "bg-yellow-100 text-yellow-800" },
  { value: "high", label: "Critical (1-7 days)", color: "bg-red-100 text-red-800" },
]

const examplePrompts = [
  {
    title: "Copyright Infringement",
    prompt:
      "Someone is using my copyrighted images on their website without permission. I want them to stop immediately and remove all my content. I registered the copyright last year and have proof of ownership.",
  },
  {
    title: "Unpaid Invoice",
    prompt:
      "A client owes me $5,000 for web development work completed 3 months ago. Despite multiple reminders, they haven't paid. I need to demand payment and threaten legal action if they don't pay within 30 days.",
  },
  {
    title: "Lease Violation",
    prompt:
      "My tenant is consistently late with rent payments and has unauthorized pets in the apartment. The lease clearly prohibits pets and requires rent by the 5th of each month. I want to give them notice to cure or quit.",
  },
  {
    title: "Harassment",
    prompt:
      "A former business partner is spreading false information about me on social media and contacting my clients with defamatory statements. I need them to stop this behavior immediately or I will pursue legal action.",
  },
]

export function PromptModeGenerator() {
  const [formData, setFormData] = useState<PromptData>({
    prompt: "",
    senderName: "",
    recipientName: "",
    jurisdiction: "",
    deadline: "",
    urgency: "",
  })

  const [generatedNotice, setGeneratedNotice] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [showPreview, setShowPreview] = useState(false)

  const updateFormData = (field: keyof PromptData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const generateFromPrompt = async () => {
    setIsGenerating(true)

    // Simulate AI processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const currentDate = new Date().toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    // Simple prompt-based generation (in real implementation, this would use AI)
    const notice = `
LEGAL NOTICE

Date: ${currentDate}

TO: ${formData.recipientName || "[Recipient Name]"}
[Recipient Address]

FROM: ${formData.senderName || "[Your Name]"}
[Your Address]

RE: ${getSubjectFromPrompt(formData.prompt)}
JURISDICTION: ${formData.jurisdiction || "[Jurisdiction]"}

Dear ${formData.recipientName || "[Recipient Name]"},

You are hereby notified of the following matter:

FACTS AND CIRCUMSTANCES:
${formData.prompt}

LEGAL GROUNDS:
Based on the circumstances described above, you are in violation of applicable laws and/or contractual obligations.

DEMANDS:
You are hereby demanded to immediately cease and desist from the activities described herein and take appropriate corrective action.

DEADLINE FOR RESPONSE: ${formData.deadline || "30 days from receipt of this notice"}

Failure to respond or comply within the specified timeframe may result in further legal action including, but not limited to, seeking monetary damages, injunctive relief, and attorney's fees.

Please govern yourself accordingly.

Dated: ${currentDate}

${formData.senderName || "[Your Name]"}

---
DISCLAIMER: This document was generated using an automated legal notice generator based on your prompt. This tool generates document drafts and does not constitute legal advice. Please consult with a qualified attorney before using this notice.
    `.trim()

    setGeneratedNotice(notice)
    setIsGenerating(false)
    setShowPreview(true)
  }

  const getSubjectFromPrompt = (prompt: string): string => {
    if (prompt.toLowerCase().includes("copyright")) return "Copyright Infringement Notice"
    if (prompt.toLowerCase().includes("payment") || prompt.toLowerCase().includes("invoice"))
      return "Payment Demand Notice"
    if (prompt.toLowerCase().includes("lease") || prompt.toLowerCase().includes("rent")) return "Lease Violation Notice"
    if (prompt.toLowerCase().includes("harassment") || prompt.toLowerCase().includes("defam"))
      return "Cease and Desist Notice"
    return "Legal Notice"
  }

  const downloadNotice = () => {
    const blob = new Blob([generatedNotice], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `legal-notice-prompt-${new Date().toISOString().split("T")[0]}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const isFormValid = formData.prompt.trim().length > 50 && formData.senderName && formData.recipientName

  const applyExamplePrompt = (prompt: string) => {
    updateFormData("prompt", prompt)
  }

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      {/* Main Prompt Interface */}
      <div className="lg:col-span-2 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl">
              <MessageSquare className="h-6 w-6" />
              Describe Your Legal Notice
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="prompt">Describe your situation in detail *</Label>
              <Textarea
                id="prompt"
                value={formData.prompt}
                onChange={(e) => updateFormData("prompt", e.target.value)}
                placeholder="Explain what happened, what you want the recipient to do, and any relevant details about your situation. Be as specific as possible - include dates, amounts, contract terms, etc."
                rows={8}
                className="resize-none"
              />
              <div className="flex justify-between items-center mt-2">
                <p className="text-sm text-slate-600">
                  {formData.prompt.length < 50 ? (
                    <span className="text-amber-600">
                      <AlertCircle className="h-4 w-4 inline mr-1" />
                      Please provide more detail (minimum 50 characters)
                    </span>
                  ) : (
                    <span className="text-green-600">
                      <CheckCircle className="h-4 w-4 inline mr-1" />
                      Good level of detail provided
                    </span>
                  )}
                </p>
                <span className="text-sm text-slate-500">{formData.prompt.length} characters</span>
              </div>
            </div>

            <div className="border-t pt-6">
              <h3 className="font-semibold text-slate-900 mb-4">Example Prompts</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {examplePrompts.map((example, index) => (
                  <Card
                    key={index}
                    className="border border-slate-200 hover:border-blue-300 transition-colors cursor-pointer"
                    onClick={() => applyExamplePrompt(example.prompt)}
                  >
                    <CardContent className="p-4">
                      <h4 className="font-medium text-slate-900 mb-2">{example.title}</h4>
                      <p className="text-sm text-slate-600 line-clamp-3">{example.prompt}</p>
                      <Button variant="outline" size="sm" className="mt-3 w-full bg-transparent">
                        Use This Example
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Generate Button */}
        <div className="flex justify-center">
          <Button
            onClick={generateFromPrompt}
            disabled={!isFormValid || isGenerating}
            size="lg"
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-8 py-4"
          >
            {isGenerating ? (
              <>
                <Sparkles className="h-5 w-5 mr-2 animate-spin" />
                Generating Notice...
              </>
            ) : (
              <>
                <Sparkles className="h-5 w-5 mr-2" />
                Generate Legal Notice
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Sidebar - Required Fields & Preview */}
      <div className="space-y-6">
        {/* Required Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Required Information</CardTitle>
            <p className="text-sm text-slate-600">These fields ensure legal completeness</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="senderName">Your Name *</Label>
              <Input
                id="senderName"
                value={formData.senderName}
                onChange={(e) => updateFormData("senderName", e.target.value)}
                placeholder="Your full legal name"
              />
            </div>
            <div>
              <Label htmlFor="recipientName">Recipient Name *</Label>
              <Input
                id="recipientName"
                value={formData.recipientName}
                onChange={(e) => updateFormData("recipientName", e.target.value)}
                placeholder="Who you're sending this to"
              />
            </div>
            <div>
              <Label htmlFor="jurisdiction">Jurisdiction</Label>
              <Input
                id="jurisdiction"
                value={formData.jurisdiction}
                onChange={(e) => updateFormData("jurisdiction", e.target.value)}
                placeholder="e.g., State of California"
              />
            </div>
            <div>
              <Label htmlFor="deadline">Response Deadline</Label>
              <Input
                id="deadline"
                value={formData.deadline}
                onChange={(e) => updateFormData("deadline", e.target.value)}
                placeholder="e.g., 30 days from receipt"
              />
            </div>
            <div>
              <Label htmlFor="urgency">Urgency Level</Label>
              <Select value={formData.urgency} onValueChange={(value) => updateFormData("urgency", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select urgency" />
                </SelectTrigger>
                <SelectContent>
                  {urgencyLevels.map((level) => (
                    <SelectItem key={level.value} value={level.value}>
                      {level.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {formData.urgency && (
                <Badge className={urgencyLevels.find((l) => l.value === formData.urgency)?.color}>
                  {urgencyLevels.find((l) => l.value === formData.urgency)?.label}
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Preview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between text-lg">
              <span>Generated Notice</span>
              {showPreview && (
                <Button onClick={downloadNotice} variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {showPreview ? (
              <div className="bg-slate-50 p-4 rounded-lg border text-xs font-mono leading-relaxed max-h-96 overflow-y-auto">
                <pre className="whitespace-pre-wrap">{generatedNotice}</pre>
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500">
                <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Your generated notice will appear here</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
