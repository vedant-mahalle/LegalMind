import { Mail, Phone, MapPin, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

export function ContactSection() {
  const contactInfo = [
    {
      icon: Mail,
      title: "Email Us",
      details: "support@legalnoticeai.com",
      description: "Get in touch for support or questions",
    },
    {
      icon: Phone,
      title: "Call Us",
      details: "+1 (555) 123-4567",
      description: "Monday to Friday, 9 AM - 6 PM EST",
    },
    {
      icon: MapPin,
      title: "Visit Us",
      details: "123 Legal Tech Ave, Suite 100",
      description: "San Francisco, CA 94105",
    },
    {
      icon: MessageCircle,
      title: "Live Chat",
      details: "Available 24/7",
      description: "Instant support when you need it",
    },
  ]

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="font-montserrat font-black text-3xl sm:text-4xl text-foreground mb-4">Get In Touch</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Have questions? We're here to help. Reach out to us through any of these channels.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {contactInfo.map((contact, index) => (
            <div key={index} className="text-center group">
              <div className="bg-accent/10 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors duration-200">
                <contact.icon className="h-8 w-8 text-accent" />
              </div>
              <h3 className="font-montserrat font-bold text-lg text-foreground mb-2">{contact.title}</h3>
              <p className="text-accent font-semibold mb-2">{contact.details}</p>
              <p className="text-muted-foreground text-sm">{contact.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-card border border-border rounded-lg p-8 text-center">
          <h3 className="font-montserrat font-bold text-2xl text-card-foreground mb-4">Ready to Get Started?</h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Join thousands of satisfied users who trust LegalNotice AI for their legal document needs. Start generating
            professional legal notices today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-3">Start Free Trial</Button>
            <Button variant="outline" className="border-border bg-transparent px-8 py-3">
              Schedule Demo
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
